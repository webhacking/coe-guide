package com.example.order.service;

import com.example.order.api.CustomerClient;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {
    private CustomerClient customerClient;

    public CustomerService(CustomerClient customerClient) {
        this.customerClient = customerClient;
    }

    @HystrixCommand(fallbackMethod = "getDefaultCustomer")
    public String getCustomer() {
        return customerClient.getCustomer();
    }

    public String getDefaultCustomer() {
        return "fallback";
    }

}
